<?php
// Add menu item
function cmc_add_admin_menu() {
    add_menu_page('Custom Mouse Cursor', 'Mouse Cursor', 'manage_options', 'custom-mouse-cursor', 'cmc_admin_page');
}
add_action('admin_menu', 'cmc_add_admin_menu');

// Admin page content
function cmc_admin_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission
    if (isset($_POST['submit'])) {
        if (!isset($_POST['cmc_nonce']) || !wp_verify_nonce($_POST['cmc_nonce'], 'cmc_save_cursor')) {
            return;
        }

        if (!empty($_FILES['cmc_cursor']['name'])) {
            $uploaded = media_handle_upload('cmc_cursor', 0);
            if (is_wp_error($uploaded)) {
                echo 'Error uploading image.';
            } else {
                update_option('cmc_cursor_url', wp_get_attachment_url($uploaded));
                echo 'Image uploaded successfully.';
            }
        }
    }

    $cursor_url = get_option('cmc_cursor_url', '');

    ?>
    <div class="wrap">
        <h1>Custom Mouse Cursor</h1>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('cmc_save_cursor', 'cmc_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Upload Cursor Image</th>
                    <td><input type="file" name="cmc_cursor" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Current Cursor</th>
                    <td>
                        <?php if ($cursor_url) : ?>
                            <img src="<?php echo esc_url($cursor_url); ?>" style="max-width: 100px;" />
                        <?php else : ?>
                            No cursor set.
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Cursor'); ?>
        </form>
    </div>
    <?php
}

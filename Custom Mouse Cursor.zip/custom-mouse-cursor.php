<?php
/**
 * Plugin Name: Tim's Custom Mouse Cursor
 * Description: A plugin to set custom mouse cursors on your website. Visit my channel for more interesting tutorials & guides: https://www.youtube.com/@Digital-Insight or https://datacrypt.io/
 * Version: 1.0
 * Author: Tim
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin directory
define('CMC_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include admin page
include(CMC_PLUGIN_DIR . 'admin-page.php');

// Enqueue scripts and styles
function cmc_enqueue_scripts() {
    wp_enqueue_script('cmc-script', plugin_dir_url(__FILE__) . 'custom-mouse-cursor.js', array('jquery'), '1.0', true);
    wp_enqueue_style('cmc-styles', plugin_dir_url(__FILE__) . 'styles.css');
}
add_action('wp_enqueue_scripts', 'cmc_enqueue_scripts');

// Add cursor URL to the script
function cmc_add_cursor_url() {
    $cursor_url = get_option('cmc_cursor_url', '');
    if ($cursor_url) {
        echo "<script>var cmcCursorUrl = '" . esc_url($cursor_url) . "';</script>";
    }
}
add_action('wp_head', 'cmc_add_cursor_url');

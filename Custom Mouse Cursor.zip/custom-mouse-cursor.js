jQuery(document).ready(function($) {
    if (typeof cmcCursorUrl !== 'undefined' && cmcCursorUrl) {
        $('body').css('cursor', 'url(' + cmcCursorUrl + '), auto');
    }
});
